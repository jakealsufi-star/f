package com.ferrie.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ShapeRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;

public final class FinderRenderer {
 public static void render(WorldRenderContext ctx,ModuleManager m){
  if(ctx.world()==null||ctx.camera()==null||ctx.matrices()==null||ctx.consumers()==null)return;
  BlockPos o=BlockPos.containing(ctx.camera().getPosition());
  draw(ctx,o,m.storageFinder,true); draw(ctx,o,m.spawnerFinder,false);
 }
 private static void draw(WorldRenderContext ctx,BlockPos o,FinderModule m,boolean storage){
  if(!m.enabled)return; int r=m.range; var cam=ctx.camera().getPosition(); PoseStack ps=ctx.matrices(); MultiBufferSource bs=ctx.consumers();
  for(BlockPos p:BlockPos.betweenClosed(o.offset(-r,-r,-r),o.offset(r,r,r))){
   if(!FerrieClient.isFinderBlock(ctx.world().getBlockState(p),storage))continue; double dx=p.getX()-cam.x,dy=p.getY()-cam.y,dz=p.getZ()-cam.z; if(dx*dx+dy*dy+dz*dz>r*r)continue;
   AABB b=new AABB(p).move(-cam.x,-cam.y,-cam.z); int c=m.color; float rr=((c>>16)&255)/255f,gg=((c>>8)&255)/255f,bb=(c&255)/255f;
   ShapeRenderer.renderLineBox(ps,bs.getBuffer(net.minecraft.client.renderer.RenderType.lines()),b.minX,b.minY,b.minZ,b.maxX,b.maxY,b.maxZ,rr,gg,bb,m.opacity);
  }
 }
}
