package com.ferrie.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.lwjgl.glfw.GLFW;

public final class FerrieClient implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();
    @Override public void onInitializeClient() {
        KeyMapping key = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.ferrie.clickgui", GLFW.GLFW_KEY_RIGHT_SHIFT, "category.ferrie"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> { while (key.consumeClick()) client.setScreen(new FerrieClickGui()); });
        WorldRenderEvents.AFTER_ENTITIES.register(context -> FinderRenderer.render(context, MODULES));
    }
    public static boolean isFinderBlock(BlockState s, boolean storage) {
        if (storage) return s.is(Blocks.CHEST)||s.is(Blocks.TRAPPED_CHEST)||s.is(Blocks.BARREL)||s.is(Blocks.DROPPER)||s.is(Blocks.DISPENSER)||s.is(Blocks.ENDER_CHEST)||s.is(Blocks.SHULKER_BOX);
        return s.is(Blocks.SPAWNER);
    }
}
