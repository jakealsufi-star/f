# Ferrie Client — Fabric 1.21.11

Includes a dark/purple ClickGUI, Storage Finder, Spawner Finder, enable/disable toggles, outline mode, opacity control, range control, and configurable target block lists. Right Shift opens the GUI.

For the requested "chillers" target, there is no vanilla Minecraft block named chiller, so the storage finder includes barrels and shulker boxes alongside chests, droppers, dispensers, and ender chests.

This package deliberately contains no anti-cheat bypass, packet spoofing, hidden-client behavior, or ban-evasion functionality.

Build with Java 21 and a Gradle/Fabric development environment. Minecraft 1.21.11 uses Fabric's remapping Loom toolchain.
