package com.ferrie.client;
public final class FinderModule {
 public enum Mode { OUTLINE, FILLED, BOTH }
 public final String name; public int color; public float opacity=.72f; public Mode mode=Mode.BOTH; public int range=48; public boolean enabled;
 public FinderModule(String n,int c){name=n;color=c;}
}
