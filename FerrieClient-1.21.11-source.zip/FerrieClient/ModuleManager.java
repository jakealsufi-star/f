package com.ferrie.client;
public final class ModuleManager {
 public final FinderModule storageFinder=new FinderModule("Storage Finder",0xB06CFF);
 public final FinderModule spawnerFinder=new FinderModule("Spawner Finder",0xFF9F43);
 public ModuleManager(){storageFinder.enabled=true;}
}
