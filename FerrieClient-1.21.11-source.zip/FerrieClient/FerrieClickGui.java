package com.ferrie.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class FerrieClickGui extends Screen {
 private final int left=70,top=45,width=540,height=310; private FinderModule selected;
 public FerrieClickGui(){super(Component.literal("Ferrie Client"));selected=FerrieClient.MODULES.storageFinder;}
 @Override protected void init(){rebuild();}
 private void rebuild(){
  clearWidgets();
  addRenderableWidget(Button.builder(Component.literal("Storage Finder"),b->{selected=FerrieClient.MODULES.storageFinder;rebuild();}).bounds(left+15,top+55,150,28).build());
  addRenderableWidget(Button.builder(Component.literal("Spawner Finder"),b->{selected=FerrieClient.MODULES.spawnerFinder;rebuild();}).bounds(left+15,top+90,150,28).build());
  addRenderableWidget(Button.builder(Component.literal(selected.enabled?"Enabled":"Disabled"),b->{selected.enabled=!selected.enabled;rebuild();}).bounds(left+195,top+70,115,28).build());
  addRenderableWidget(Button.builder(Component.literal("Mode: "+selected.mode),b->{selected.mode=switch(selected.mode){case OUTLINE->FinderModule.Mode.FILLED;case FILLED->FinderModule.Mode.BOTH;case BOTH->FinderModule.Mode.OUTLINE;};rebuild();}).bounds(left+320,top+70,180,28).build());
  addRenderableWidget(Button.builder(Component.literal("Opacity -"),b->{selected.opacity=Math.max(.1f,selected.opacity-.1f);rebuild();}).bounds(left+195,top+120,95,24).build());
  addRenderableWidget(Button.builder(Component.literal("Opacity +"),b->{selected.opacity=Math.min(1f,selected.opacity+.1f);rebuild();}).bounds(left+300,top+120,95,24).build());
  addRenderableWidget(Button.builder(Component.literal("Range -"),b->{selected.range=Math.max(8,selected.range-8);rebuild();}).bounds(left+195,top+155,95,24).build());
  addRenderableWidget(Button.builder(Component.literal("Range +"),b->{selected.range=Math.min(96,selected.range+8);rebuild();}).bounds(left+300,top+155,95,24).build());
 }
 @Override public void render(GuiGraphics g,int mx,int my,float d){renderBackground(g,mx,my,d);g.fill(left,top,left+width,top+height,0xF0141420);g.fill(left,top,left+width,top+3,0xFFB06CFF);g.drawString(font,"FERRIE CLIENT",left+15,top+18,0xFFFFFFFF,false);g.drawString(font,"Block Finders",left+15,top+36,0xFFAAAAB8,false);g.drawString(font,selected.name,left+195,top+50,0xFFFFFFFF,false);g.drawString(font,"Opacity: "+(int)(selected.opacity*100)+"%",left+405,top+125,0xFFAAAAB8,false);g.drawString(font,"Range: "+selected.range,left+405,top+160,0xFFAAAAB8,false);super.render(g,mx,my,d);}
 @Override public boolean isPauseScreen(){return false;}
}
